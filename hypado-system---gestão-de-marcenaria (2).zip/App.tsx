
import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Factory, 
  ShieldCheck, 
  BarChart3, 
  Menu, 
  X, 
  Bell,
  Search,
  Briefcase,
  Layers,
  ShoppingCart,
  DollarSign,
  Settings,
  HardHat
} from 'lucide-react';
import { MOCK_CLIENTS, MOCK_PROJECTS, MOCK_ENVIRONMENTS } from './mockData';
import { Client, Project, Environment, Supplier, Material, Quotation, Company, Installer } from './types';
import DashboardView from './components/DashboardView';
import CRMView from './components/CRMView';
import ObrasView from './components/ObrasView';
import PCPView from './components/PCPView';
import QualityView from './components/QualityView';
import AnalyticsView from './components/AnalyticsView';
import EnvironmentsLibraryView from './components/EnvironmentsLibraryView';
import ProcurementView from './components/ProcurementView';
import CompanySettingsView from './components/CompanySettingsView';
import InstallerListView from './components/InstallerListView';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'clientes' | 'obras' | 'pcp' | 'quality' | 'analytics' | 'ambientes' | 'compras' | 'config' | 'montadores'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [clients, setClients] = useState<Client[]>(MOCK_CLIENTS);
  
  const [procurementSubTab, setProcurementSubTab] = useState<'cotacoes' | 'apontamento' | 'diario' | 'produtos' | 'fornecedores'>('cotacoes');
  const [selectedProcurementOSId, setSelectedProcurementOSId] = useState('');

  const [projects, setProjects] = useState<Project[]>(MOCK_PROJECTS.map(p => ({
    ...p,
    expenses: [],
    currentStatus: p.currentStatus
  })));
  
  const [environments, setEnvironments] = useState<Environment[]>(MOCK_ENVIRONMENTS);
  const [expenseCategories, setExpenseCategories] = useState<string[]>(['Material', 'Frete', 'Montagem', 'Fitação', 'Terceirizados', 'Uber', 'Alimentação']);

  const [company, setCompany] = useState<Company>({
    name: 'Hypado Planejados',
    cnpj: '00.000.000/0001-00',
    phone: '(11) 99999-8888',
    email: 'contato@hypado.com.br',
    address: 'Rua da Marcenaria, 123 - Polo Industrial'
  });

  const [installers, setInstallers] = useState<Installer[]>([
    { 
      id: 'i1', name: 'Carlos Eduardo Silva', cpf: '123.456.789-00', phone: '(11) 98888-1111', 
      status: 'Ativo', specialty: 'Cozinhas', observations: 'Especialista em ferragens Blum.',
      installationsCount: 47, averageRating: 9.4, totalBonus: 4230, role: 'Montador'
    },
    { 
      id: 'i2', name: 'Fernando Costa', cpf: '234.567.890-11', phone: '(11) 96666-3333', 
      status: 'Ativo', specialty: 'Móveis Gerais', observations: '',
      installationsCount: 28, averageRating: 9.1, totalBonus: 2450, role: 'Marceneiro'
    },
    { 
      id: 'i3', name: 'Roberto Almeida', cpf: '345.678.901-22', phone: '(11) 97777-2222', 
      status: 'Ativo', specialty: 'Closets', observations: 'Montador rápido e limpo.',
      installationsCount: 63, averageRating: 8.7, totalBonus: 5280, role: 'Montador'
    }
  ]);

  const [suppliers, setSuppliers] = useState<Supplier[]>([
    { id: 's1', name: 'Madeira & Cia', type: 'Material', contact: 'comercial@madeira.com' },
    { id: 's2', name: 'Ferragens Prime (Blum)', type: 'Material', contact: 'vendas@prime.com' },
    { id: 's3', name: 'Central de Corte VIP', type: 'Serviço (Corte/Fitação)', contact: 'producao@vip.com.br' }
  ]);

  const [materials, setMaterials] = useState<Material[]>([
    { id: 'm1', name: 'MDF Louro Freijó 18mm', category: 'MDF', unit: 'Chapa' },
    { id: 'm2', name: 'MDF Branco Diamante 15mm', category: 'MDF', unit: 'Chapa' },
    { id: 'm3', name: 'Dobradiça Blumotion 35mm', category: 'Ferragem', unit: 'Par' },
    { id: 'm4', name: 'Serviço de Corte e Fitação', category: 'Serviço', unit: 'M2' }
  ]);

  const [quotations, setQuotations] = useState<Quotation[]>([]);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'clientes', label: 'Clientes', icon: Users },
    { id: 'obras', label: 'Ordens de Serviço (OS)', icon: Briefcase },
    { id: 'compras', label: 'Suprimentos & Serviços', icon: ShoppingCart },
    { id: 'pcp', label: 'Produção', icon: Factory },
    { id: 'montadores', label: 'Equipe', icon: HardHat },
    { id: 'quality', label: 'Qualidade', icon: ShieldCheck },
    { id: 'ambientes', label: 'Biblioteca', icon: Layers },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'config', label: 'Minha Empresa', icon: Settings },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <DashboardView projects={projects} clients={clients} />;
      case 'clientes': return <CRMView clients={clients} setClients={setClients} projects={projects} />;
      case 'obras': return (
        <ObrasView 
          projects={projects} 
          setProjects={setProjects} 
          clients={clients} 
          availableEnvironments={environments} 
          setEnvironments={setEnvironments}
          expenseCategories={expenseCategories}
          setExpenseCategories={setExpenseCategories}
          company={company}
          installers={installers}
        />
      );
      case 'compras': return (
        <ProcurementView 
          projects={projects} 
          suppliers={suppliers} 
          setSuppliers={setSuppliers} 
          materials={materials} 
          setMaterials={setMaterials} 
          purchaseOrders={quotations} 
          setPurchaseOrders={setQuotations}
          setProjects={setProjects}
          company={company}
          installers={installers}
          clients={clients}
          externalActiveTab={procurementSubTab}
          setExternalActiveTab={setProcurementSubTab}
          externalSelectedOSId={selectedProcurementOSId}
          setExternalSelectedOSId={setSelectedProcurementOSId}
        />
      );
      case 'pcp': return (
        <PCPView 
          projects={projects} 
          setProjects={setProjects} 
          purchaseOrders={[]} 
          installers={installers}
          suppliers={suppliers}
          goToProcurementMDO={(osId) => {
            setSelectedProcurementOSId(osId);
            setProcurementSubTab('apontamento');
            setActiveTab('compras');
          }}
        />
      );
      case 'montadores': return <InstallerListView installers={installers} setInstallers={setInstallers} projects={projects} />;
      case 'quality': return <QualityView projects={projects} setProjects={setProjects} installers={installers} setInstallers={setInstallers} />;
      case 'ambientes': return <EnvironmentsLibraryView environments={environments} setEnvironments={setEnvironments} />;
      case 'analytics': return <AnalyticsView projects={projects} />;
      case 'config': return <CompanySettingsView company={company} setCompany={setCompany} />;
      default: return <DashboardView projects={projects} clients={clients} />;
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 text-white transform transition-transform duration-200 ease-in-out md:relative md:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} print:hidden`}>
        <div className="flex flex-col h-full">
          <div className="p-8 border-b border-slate-800 flex items-center gap-3">
            {company.logo ? (
              <img src={company.logo} alt="Logo" className="w-10 h-10 rounded-lg object-cover" />
            ) : (
              <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center font-bold text-xl text-slate-900 shadow-lg shadow-amber-500/20">H</div>
            )}
            <h1 className="text-xl font-bold tracking-tight truncate">{company.name.split(' ')[0]} <span className="text-amber-500">System</span></h1>
          </div>
          <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id as any); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === item.id ? 'bg-amber-500 text-slate-900 shadow-lg shadow-amber-500/20 font-semibold' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              >
                <item.icon size={20} />
                {item.label}
              </button>
            ))}
          </nav>
          
          <div className="p-6 border-t border-slate-800">
             <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest italic">Hypado System</p>
             <p className="text-[10px] text-slate-600 font-bold uppercase tracking-widest mt-1 italic">v1.2 • Gestão & Qualidade</p>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 py-4 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-4">
            <button onClick={toggleSidebar} className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
              {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <h2 className="text-lg font-bold text-slate-800 hidden md:block">{navItems.find(i => i.id === activeTab)?.label}</h2>
          </div>
          <div className="flex items-center gap-3">
             <button className="p-2 text-slate-600 hover:bg-slate-100 rounded-full relative"><Bell size={20} /><span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span></button>
             <div className="w-8 h-8 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center font-bold text-xs">AD</div>
          </div>
        </header>
        <div className="p-6 md:p-8 print:p-0">{renderContent()}</div>
      </main>
    </div>
  );
};

export default App;
