
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Project } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Estado para evitar spam de requisições se a cota estiver estourada
let quotaExceededUntil = 0;

/**
 * Helper para executar chamadas com Retry e Backoff Exponencial
 */
async function withRetry<T>(fn: () => Promise<T>, retries = 1, delay = 5000): Promise<T> {
  const now = Date.now();
  if (now < quotaExceededUntil) {
    throw new Error("429: Limite de cota atingido. Aguarde a restauração automática em breve.");
  }

  try {
    return await fn();
  } catch (error: any) {
    const errorMsg = error?.message || "";
    // Detecta erros de cota (429 ou RESOURCE_EXHAUSTED)
    const isQuotaError = errorMsg.includes('429') || errorMsg.includes('RESOURCE_EXHAUSTED') || errorMsg.includes('quota');
    
    if (isQuotaError) {
      // Bloqueia novas tentativas por 60 segundos para respeitar o limite do Google
      quotaExceededUntil = Date.now() + 60000; 
      
      if (retries > 0) {
        await new Promise(resolve => setTimeout(resolve, delay));
        return withRetry(fn, retries - 1, delay * 2);
      }
    }
    throw error;
  }
}

export async function analyzeProductionBottlenecks(projects: Project[]) {
  const model = 'gemini-3-pro-preview';
  
  const prompt = `
    Analise os dados de produção da marcenaria:
    ${JSON.stringify(projects.map(p => ({ id: p.id, status: p.currentStatus, valor: p.value, entrega: p.promisedDate })), null, 2)}
    
    Identifique gargalos e dê 3 conselhos práticos para acelerar as obras em Português.
  `;

  try {
    const response = await withRetry<GenerateContentResponse>(() => ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        temperature: 0.7
      }
    }));
    
    return response.text;
  } catch (error: any) {
    console.error("Erro Gemini:", error);
    if (error?.message?.includes('429')) {
      return "⚠️ O limite de cota gratuita do Google foi atingido. A inteligência de dados retornará em instantes.";
    }
    return "Não foi possível gerar a análise de inteligência no momento.";
  }
}

export async function analyzeReceipt(base64Image: string) {
  const model = 'gemini-3-pro-preview';
  const prompt = "Extraia valor total e descrição desta nota. JSON: { \"totalValue\": number, \"description\": \"string\" }";

  try {
    const response = await withRetry<GenerateContentResponse>(() => ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            totalValue: { type: Type.NUMBER },
            description: { type: Type.STRING }
          },
          required: ["totalValue", "description"]
        }
      }
    }));

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Erro Visão Gemini:", error);
    return null;
  }
}
