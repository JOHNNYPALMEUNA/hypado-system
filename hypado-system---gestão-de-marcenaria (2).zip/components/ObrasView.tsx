
import React, { useState, useMemo } from 'react';
import { Project, Client, Environment, Expense, Company, MemorialDescritivo, EnvironmentWithDetails, MdfPart, ProductionStatus, Appliance, HardwareItem, Installer, OutsourcedService, OutsourcedStatus } from '../types';
import { 
  Plus, X, MapPin, Printer, FileText, 
  CheckCircle2, ChevronDown, ChevronUp, AlertTriangle,
  Zap, Wind, Trash2, DollarSign, Calendar, Edit3, Palette, Layers,
  Power, Package, Boxes, ClipboardList, Hammer, HardHat, GlassWater, Paintbrush, Scissors, Save, TrendingDown, Coffee, Car, Monitor, Settings2, Check, Lock, Archive, History, ChevronRight,
  PlusCircle, Settings, Building2
} from 'lucide-react';

interface Props {
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  clients: Client[];
  availableEnvironments: Environment[];
  setEnvironments: React.Dispatch<React.SetStateAction<Environment[]>>;
  expenseCategories: string[];
  setExpenseCategories: React.Dispatch<React.SetStateAction<string[]>>;
  company: Company;
  installers: Installer[];
}

const INITIAL_MEMORIAL = (): MemorialDescritivo => ({
  mdfParts: [{ id: `mdf-${Date.now()}`, partName: 'Caixaria', brandColor: 'Branco Standard', thickness: '15mm' }],
  fitacao: 'PVC 0.45mm',
  fundo: '6mm Branco Encaixado',
  hardwareItems: [],
  appliances: []
});

const ObrasView: React.FC<Props> = ({ 
  projects, setProjects, clients, availableEnvironments, setEnvironments,
  expenseCategories, setExpenseCategories, company, installers
}) => {
  const [osTab, setOsTab] = useState<'ativas' | 'arquivadas'>('ativas');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [activeDetailTab, setActiveDetailTab] = useState<'memorial' | 'financeiro'>('memorial');
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [activeEnvForm, setActiveEnvForm] = useState<string | null>(null);
  
  const [outsourcedCategories, setOutsourcedCategories] = useState<string[]>(['Vidraçaria', 'Pintura de Portas', 'Serralheria', 'Mármore', 'Estofaria', 'Automação']);
  const [isManagingCats, setIsManagingCats] = useState(false);
  const [newCatName, setNewCatName] = useState('');

  const activeProjects = projects.filter(p => p.currentStatus !== 'Finalizada');
  const archivedProjects = projects.filter(p => p.currentStatus === 'Finalizada');

  const [formData, setFormData] = useState({
    clientId: '',
    workName: '',
    selectedEnvironments: [] as string[],
    environmentsDetails: {} as Record<string, MemorialDescritivo>,
    environmentsValues: {} as Record<string, string>,
    outsourcedServices: [] as OutsourcedService[],
    value: '', 
    contractDate: new Date().toISOString().split('T')[0], 
    promisedDate: '',
    installerId: '',
    workAddress: '',
    currentStatus: 'Projeto' as ProductionStatus
  });

  const openCreateModal = () => {
    setEditingProjectId(null);
    setFormData({
      clientId: '', workName: '', selectedEnvironments: [], environmentsDetails: {}, environmentsValues: {},
      outsourcedServices: [], value: '', contractDate: new Date().toISOString().split('T')[0], 
      promisedDate: '', installerId: '', workAddress: '', currentStatus: 'Projeto'
    });
    setIsModalOpen(true);
  };

  const openEditModal = (os: Project) => {
    if (os.currentStatus === 'Finalizada') {
      alert("OBRA BLOQUEADA: Projetos finalizados não podem ser editados.");
      return;
    }
    setEditingProjectId(os.id);
    const envDetails: Record<string, MemorialDescritivo> = {};
    const envValues: Record<string, string> = {};
    (os.environmentsDetails || []).forEach(env => {
      envDetails[env.name] = env.memorial || INITIAL_MEMORIAL();
      envValues[env.name] = (env.value || 0).toString();
    });
    setFormData({
      clientId: os.clientId,
      workName: os.workName,
      selectedEnvironments: os.environments,
      environmentsDetails: envDetails,
      environmentsValues: envValues,
      outsourcedServices: os.outsourcedServices || [],
      value: os.value.toString(),
      contractDate: os.contractDate,
      promisedDate: os.promisedDate,
      installerId: os.installerId || '',
      workAddress: os.workAddress,
      currentStatus: os.currentStatus
    });
    setIsModalOpen(true);
  };

  const toggleEnvironment = (envName: string) => {
    setFormData(prev => {
      const selected = prev.selectedEnvironments.includes(envName);
      const newSelected = selected 
        ? prev.selectedEnvironments.filter(e => e !== envName)
        : [...prev.selectedEnvironments, envName];
      
      const newDetails = { ...prev.environmentsDetails };
      if (!selected && !newDetails[envName]) newDetails[envName] = INITIAL_MEMORIAL();
      
      return { ...prev, selectedEnvironments: newSelected, environmentsDetails: newDetails };
    });
  };

  const updateMemorial = (envName: string, field: keyof MemorialDescritivo, val: any) => {
    setFormData(prev => ({
      ...prev,
      environmentsDetails: {
        ...prev.environmentsDetails,
        [envName]: { ...prev.environmentsDetails[envName], [field]: val }
      }
    }));
  };

  const handleAddMdf = (envName: string) => {
    const newPart: MdfPart = { id: `mdf-${Date.now()}`, partName: 'Nova Parte', brandColor: 'A definir', thickness: '15mm' };
    updateMemorial(envName, 'mdfParts', [...formData.environmentsDetails[envName].mdfParts, newPart]);
  };

  const handleAddHardware = (envName: string) => {
    const newItem: HardwareItem = { id: `hw-${Date.now()}`, category: 'Dobradiça', brand: '', model: '' };
    updateMemorial(envName, 'hardwareItems', [...formData.environmentsDetails[envName].hardwareItems, newItem]);
  };

  const handleAddAppliance = (envName: string) => {
    const newItem: Appliance = { id: `ap-${Date.now()}`, item: '', brandModel: '', voltage: '220v', needsVentilation: true, manualConfirmed: false };
    updateMemorial(envName, 'appliances', [...formData.environmentsDetails[envName].appliances, newItem]);
  };

  const handleAddOutsourced = () => {
    const newService: OutsourcedService = {
      id: `out-${Date.now()}`,
      category: outsourcedCategories[0],
      description: '',
      supplierName: '',
      status: 'Pendente',
      value: 0
    };
    setFormData(prev => ({ ...prev, outsourcedServices: [...prev.outsourcedServices, newService] }));
  };

  const updateOutsourced = (id: string, field: keyof OutsourcedService, val: any) => {
    setFormData(prev => ({
      ...prev,
      outsourcedServices: prev.outsourcedServices.map(s => s.id === id ? { ...s, [field]: val } : s)
    }));
  };

  const handleSubmitOS = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.id === formData.clientId);
    if (!client) return;

    const projectData = {
      clientId: client.id,
      clientName: client.name,
      workName: formData.workName,
      environments: formData.selectedEnvironments,
      environmentsDetails: formData.selectedEnvironments.map(env => ({
        name: env,
        type: 'Geral',
        memorial: formData.environmentsDetails[env] || INITIAL_MEMORIAL(),
        value: Number(formData.environmentsValues[env] || 0)
      })),
      outsourcedServices: formData.outsourcedServices,
      value: Number(formData.value),
      contractDate: formData.contractDate,
      promisedDate: formData.promisedDate,
      team: installers.find(i => i.id === formData.installerId)?.name || 'N/A',
      installerId: formData.installerId,
      workAddress: formData.workAddress,
      currentStatus: formData.currentStatus,
      materialsDelivered: editingProjectId ? projects.find(p => p.id === editingProjectId)?.materialsDelivered : false
    };

    if (editingProjectId) {
      setProjects(prev => prev.map(p => p.id === editingProjectId ? { ...p, ...projectData as any } : p));
    } else {
      setProjects(prev => [{
        id: `OS-${Date.now().toString().slice(-4)}`,
        ...projectData as any,
        expenses: [],
        history: [{ status: formData.currentStatus, timestamp: new Date().toISOString() }]
      }, ...prev]);
    }
    setIsModalOpen(false);
  };

  const currentViewedProject = useMemo(() => 
    projects.find(p => p.id === selectedProjectId) || null, 
    [projects, selectedProjectId]
  );

  const calculateFinancials = (project: Project) => {
    const totalRevenue = project.value;
    const directExpenses = (project.expenses || []).reduce((acc, e) => acc + e.value, 0);
    const outsourcedCosts = (project.outsourcedServices || []).reduce((acc, s) => acc + (s.value || 0), 0);
    const totalCosts = directExpenses + outsourcedCosts;
    const profit = totalRevenue - totalCosts;
    const margin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;
    
    return { totalRevenue, totalCosts, directExpenses, outsourcedCosts, profit, margin };
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* HEADER NAVEGAÇÃO */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 no-print">
        <div>
          <h3 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">Arquitetura de Ordens de Serviço</h3>
          <div className="flex bg-slate-200/50 p-1 rounded-2xl border mt-4 w-fit">
            <button onClick={() => setOsTab('ativas')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${osTab === 'ativas' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}>Ativas ({activeProjects.length})</button>
            <button onClick={() => setOsTab('arquivadas')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${osTab === 'arquivadas' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800'}`}>Arquivo ({archivedProjects.length})</button>
          </div>
        </div>
        {osTab === 'ativas' && (
          <button onClick={openCreateModal} className="bg-amber-500 text-slate-900 px-8 py-4 rounded-2xl font-black uppercase tracking-widest flex items-center gap-2 hover:bg-slate-900 hover:text-white transition-all shadow-xl active:scale-95"><Plus size={20} /> Nova OS Industrial</button>
        )}
      </div>

      {/* GRID DE CARDS */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {(osTab === 'ativas' ? activeProjects : archivedProjects).map(os => (
          <div key={os.id} className={`bg-white rounded-[48px] border shadow-sm p-10 flex flex-col justify-between group transition-all ${os.currentStatus === 'Finalizada' ? 'opacity-70 grayscale-[0.5]' : 'hover:border-amber-500'}`}>
             <div className="flex justify-between items-start mb-8">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-[10px] font-black uppercase bg-slate-900 text-white px-4 py-1.5 rounded-full italic tracking-widest">{os.id}</span>
                    <span className={`text-[10px] font-black uppercase px-4 py-1.5 rounded-full italic tracking-widest ${os.currentStatus === 'Finalizada' ? 'bg-emerald-50 text-white' : 'bg-amber-50 text-amber-600'}`}>{os.currentStatus}</span>
                    {os.currentStatus === 'Finalizada' ? <Lock size={16} className="text-slate-400" /> : <button onClick={() => openEditModal(os)} className="p-2 text-slate-400 hover:text-indigo-600 transition-all"><Edit3 size={16}/></button>}
                  </div>
                  <h4 className="text-3xl font-black text-slate-900 uppercase italic tracking-tighter mb-2 leading-none">{os.workName}</h4>
                  <p className="text-xs text-slate-500 font-black uppercase tracking-widest italic">{os.clientName}</p>
                </div>
                <div className="text-right">
                   <p className={`text-3xl font-black tracking-tighter italic ${os.currentStatus === 'Finalizada' ? 'text-slate-400' : 'text-emerald-600'}`}>R$ {os.value.toLocaleString()}</p>
                </div>
             </div>
             
             <button onClick={() => { setSelectedProjectId(os.id); setActiveDetailTab('memorial'); }} className="w-full py-5 bg-slate-900 text-white font-black uppercase text-xs tracking-[0.2em] rounded-[24px] hover:bg-amber-500 hover:text-slate-900 shadow-2xl flex items-center justify-center gap-3 transition-all">
                {os.currentStatus === 'Finalizada' ? <History size={20}/> : <ClipboardList size={20}/>} Ver Dossiê Técnico
             </button>
          </div>
        ))}
      </div>

      {/* MODAL CRIAR/EDITAR OS */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-0 md:p-4">
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-xl" onClick={() => setIsModalOpen(false)} />
          <div className="relative bg-white w-full max-w-7xl h-full md:h-[95vh] rounded-[48px] shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95">
             <div className="p-10 bg-slate-900 text-white flex justify-between items-center">
                <h4 className="text-3xl font-black uppercase italic tracking-tighter">Estruturação Industrial</h4>
                <button onClick={() => setIsModalOpen(false)} className="p-4 hover:bg-slate-800 rounded-full transition-all text-white"><X size={32}/></button>
             </div>
             
             <form onSubmit={handleSubmitOS} className="flex-1 overflow-y-auto p-12 space-y-12 bg-slate-50 custom-scrollbar">
                {/* DADOS GERAIS */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 bg-white p-10 rounded-[40px] border shadow-sm">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase italic ml-2">Cliente</label>
                      <select className="w-full bg-slate-50 p-5 rounded-[24px] font-black outline-none border-2 border-transparent focus:border-amber-500 transition-all text-sm italic" value={formData.clientId} onChange={e => setFormData({...formData, clientId: e.target.value})} required>
                         <option value="">Selecionar Cliente</option>
                         {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase italic ml-2">Obra</label>
                      <input type="text" className="w-full bg-slate-50 p-5 rounded-[24px] font-black outline-none border-2 border-transparent focus:border-amber-500 transition-all text-sm italic uppercase" value={formData.workName} onChange={e => setFormData({...formData, workName: e.target.value})} placeholder="Ex: Apartamento 402" required />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase italic ml-2">Valor Venda (R$)</label>
                      <input type="number" className="w-full bg-slate-50 p-5 rounded-[24px] font-black outline-none border-2 border-transparent focus:border-amber-500 transition-all text-lg text-emerald-600" value={formData.value} onChange={e => setFormData({...formData, value: e.target.value})} placeholder="0,00" required />
                   </div>
                </div>

                {/* AMBIENTES */}
                <div className="space-y-8">
                   <h5 className="text-xl font-black uppercase italic tracking-tighter border-b-4 border-amber-500 w-fit pb-2">Configuração de Ambientes</h5>
                   <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {availableEnvironments.map(env => (
                         <button key={env.id} type="button" onClick={() => toggleEnvironment(env.name)} className={`p-4 rounded-[24px] font-black uppercase italic text-[10px] tracking-widest transition-all border-2 ${formData.selectedEnvironments.includes(env.name) ? 'bg-slate-900 text-white border-slate-900 shadow-xl' : 'bg-white text-slate-400 border-slate-100 hover:border-amber-500'}`}>
                            {env.name}
                         </button>
                      ))}
                   </div>
                </div>

                {/* DETALHAMENTO TÉCNICO DOS AMBIENTES - MDF, FERRAGENS, ELETROS */}
                {formData.selectedEnvironments.map(envName => (
                   <div key={envName} className="bg-white p-10 rounded-[40px] border shadow-sm space-y-10 animate-in slide-in-from-top-4">
                      <div className="flex justify-between items-center border-b pb-6">
                         <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-slate-900 text-amber-500 rounded-2xl flex items-center justify-center font-black"><Layers size={24}/></div>
                            <h6 className="text-2xl font-black uppercase italic tracking-tighter text-slate-900">{envName}</h6>
                         </div>
                         <button type="button" onClick={() => setActiveEnvForm(activeEnvForm === envName ? null : envName)} className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900">
                            {activeEnvForm === envName ? 'Recolher Detalhes' : 'Editar Especificações Técnicas'} {activeEnvForm === envName ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}
                         </button>
                      </div>

                      {activeEnvForm === envName && (
                         <div className="space-y-10">
                            {/* MDF CONFIG */}
                            <div className="space-y-4">
                               <div className="flex justify-between items-center">
                                  <p className="text-xs font-black uppercase italic tracking-widest text-slate-400 flex items-center gap-2"><Boxes size={14}/> Configuração de MDF</p>
                                  <button type="button" onClick={() => handleAddMdf(envName)} className="text-[9px] font-black uppercase bg-slate-100 px-3 py-1 rounded-full hover:bg-slate-200">+ Adicionar Parte</button>
                               </div>
                               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                  {formData.environmentsDetails[envName].mdfParts.map((part, idx) => (
                                     <div key={part.id} className="bg-slate-50 p-4 rounded-2xl space-y-3 relative group">
                                        <button type="button" onClick={() => {
                                           const parts = [...formData.environmentsDetails[envName].mdfParts];
                                           parts.splice(idx, 1);
                                           updateMemorial(envName, 'mdfParts', parts);
                                        }} className="absolute top-2 right-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><X size={14}/></button>
                                        <input type="text" className="w-full bg-white px-3 py-2 rounded-xl text-[10px] font-black uppercase border-none outline-none shadow-sm" value={part.partName} onChange={e => {
                                           const parts = [...formData.environmentsDetails[envName].mdfParts];
                                           parts[idx].partName = e.target.value;
                                           updateMemorial(envName, 'mdfParts', parts);
                                        }} placeholder="Parte (Ex: Caixaria)" />
                                        <input type="text" className="w-full bg-white px-3 py-2 rounded-xl text-[10px] font-bold border-none outline-none shadow-sm" value={part.brandColor} onChange={e => {
                                           const parts = [...formData.environmentsDetails[envName].mdfParts];
                                           parts[idx].brandColor = e.target.value;
                                           updateMemorial(envName, 'mdfParts', parts);
                                        }} placeholder="Marca/Cor" />
                                        <select className="w-full bg-white px-3 py-2 rounded-xl text-[10px] font-bold border-none outline-none shadow-sm" value={part.thickness} onChange={e => {
                                           const parts = [...formData.environmentsDetails[envName].mdfParts];
                                           parts[idx].thickness = e.target.value;
                                           updateMemorial(envName, 'mdfParts', parts);
                                        }}>
                                           <option value="6mm">6mm</option><option value="15mm">15mm</option><option value="18mm">18mm</option><option value="25mm">25mm</option>
                                        </select>
                                     </div>
                                  ))}
                               </div>
                            </div>

                            {/* HARDWARE CONFIG */}
                            <div className="space-y-4">
                               <div className="flex justify-between items-center">
                                  <p className="text-xs font-black uppercase italic tracking-widest text-slate-400 flex items-center gap-2"><Settings2 size={14}/> Ferragens & Sistemas</p>
                                  <button type="button" onClick={() => handleAddHardware(envName)} className="text-[9px] font-black uppercase bg-slate-100 px-3 py-1 rounded-full hover:bg-slate-200">+ Novo Item</button>
                               </div>
                               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {formData.environmentsDetails[envName].hardwareItems.map((hw, idx) => (
                                     <div key={hw.id} className="bg-slate-50 p-4 rounded-2xl flex gap-3 relative group">
                                        <button type="button" onClick={() => {
                                           const hws = [...formData.environmentsDetails[envName].hardwareItems];
                                           hws.splice(idx, 1);
                                           updateMemorial(envName, 'hardwareItems', hws);
                                        }} className="absolute top-2 right-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><X size={14}/></button>
                                        <select className="flex-1 bg-white px-3 py-2 rounded-xl text-[10px] font-black uppercase border-none outline-none" value={hw.category} onChange={e => {
                                           const hws = [...formData.environmentsDetails[envName].hardwareItems];
                                           hws[idx].category = e.target.value;
                                           updateMemorial(envName, 'hardwareItems', hws);
                                        }}>
                                           <option value="Dobradiça">Dobradiça</option><option value="Corrediça">Corrediça</option><option value="Puxador">Puxador</option><option value="Pistão">Pistão</option><option value="Acessório">Acessório</option>
                                        </select>
                                        <input type="text" className="flex-1 bg-white px-3 py-2 rounded-xl text-[10px] font-bold border-none outline-none" value={hw.brand} onChange={e => {
                                           const hws = [...formData.environmentsDetails[envName].hardwareItems];
                                           hws[idx].brand = e.target.value;
                                           updateMemorial(envName, 'hardwareItems', hws);
                                        }} placeholder="Marca (Ex: Blum)" />
                                        <input type="text" className="flex-1 bg-white px-3 py-2 rounded-xl text-[10px] font-bold border-none outline-none" value={hw.model} onChange={e => {
                                           const hws = [...formData.environmentsDetails[envName].hardwareItems];
                                           hws[idx].model = e.target.value;
                                           updateMemorial(envName, 'hardwareItems', hws);
                                        }} placeholder="Modelo" />
                                     </div>
                                  ))}
                               </div>
                            </div>

                            {/* APPLIANCES CONFIG */}
                            <div className="space-y-4">
                               <div className="flex justify-between items-center">
                                  <p className="text-xs font-black uppercase italic tracking-widest text-slate-400 flex items-center gap-2"><Power size={14}/> Eletros & Instalações</p>
                                  <button type="button" onClick={() => handleAddAppliance(envName)} className="text-[9px] font-black uppercase bg-slate-100 px-3 py-1 rounded-full hover:bg-slate-200">+ Novo Eletro</button>
                               </div>
                               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {formData.environmentsDetails[envName].appliances.map((ap, idx) => (
                                     <div key={ap.id} className="bg-slate-50 p-4 rounded-2xl flex gap-3 relative group items-center">
                                        <button type="button" onClick={() => {
                                           const aps = [...formData.environmentsDetails[envName].appliances];
                                           aps.splice(idx, 1);
                                           updateMemorial(envName, 'appliances', aps);
                                        }} className="absolute top-2 right-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"><X size={14}/></button>
                                        <input type="text" className="flex-1 bg-white px-3 py-2 rounded-xl text-[10px] font-black uppercase border-none outline-none" value={ap.item} onChange={e => {
                                           const aps = [...formData.environmentsDetails[envName].appliances];
                                           aps[idx].item = e.target.value;
                                           updateMemorial(envName, 'appliances', aps);
                                        }} placeholder="Item (Ex: Forno)" />
                                        <select className="bg-white px-3 py-2 rounded-xl text-[10px] font-bold border-none outline-none" value={ap.voltage} onChange={e => {
                                           const aps = [...formData.environmentsDetails[envName].appliances];
                                           aps[idx].voltage = e.target.value as any;
                                           updateMemorial(envName, 'appliances', aps);
                                        }}>
                                           <option value="110v">110v</option><option value="220v">220v</option><option value="Bivolt">Bivolt</option>
                                        </select>
                                        <label className="flex items-center gap-1 text-[8px] font-black uppercase text-slate-400">
                                           <input type="checkbox" checked={ap.needsVentilation} onChange={e => {
                                              const aps = [...formData.environmentsDetails[envName].appliances];
                                              aps[idx].needsVentilation = e.target.checked;
                                              updateMemorial(envName, 'appliances', aps);
                                           }} /> Ventilar
                                        </label>
                                     </div>
                                  ))}
                               </div>
                            </div>
                         </div>
                      )}
                   </div>
                ))}

                {/* TERCEIRIZADOS - PREVISÃO NA ABERTURA (FLUIDO) */}
                <div className="space-y-8 pt-10 border-t-4 border-slate-100">
                   <div className="flex justify-between items-center">
                      <div>
                        <h5 className="text-xl font-black uppercase italic tracking-tighter border-b-4 border-indigo-500 w-fit pb-2">Previsão de Serviços Externos</h5>
                        <p className="text-[9px] font-black text-slate-400 uppercase mt-2 italic tracking-widest">Fornecedores e valores exatos podem ser definidos depois, na fase de produção</p>
                      </div>
                      <div className="flex gap-4">
                        <button type="button" onClick={() => setIsManagingCats(true)} className="p-4 bg-slate-100 text-slate-500 rounded-2xl hover:bg-slate-200 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"><Settings size={18}/> Categorias</button>
                        <button type="button" onClick={handleAddOutsourced} className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center gap-2 hover:bg-slate-900 transition-all shadow-xl active:scale-95"><PlusCircle size={18}/> Novo Terceiro</button>
                      </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {formData.outsourcedServices.map((service, idx) => (
                         <div key={service.id} className="bg-white p-8 rounded-[40px] border-2 border-slate-50 shadow-sm relative group animate-in slide-in-from-right-4 hover:border-indigo-300 transition-all">
                            <button type="button" onClick={() => setFormData(p => ({...p, outsourcedServices: p.outsourcedServices.filter(s => s.id !== service.id)}))} className="absolute top-6 right-6 p-2 text-slate-300 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 size={20}/></button>
                            <div className="grid grid-cols-1 gap-6">
                               <div className="flex gap-4">
                                  <div className="flex-1">
                                     <label className="text-[9px] font-black text-slate-400 uppercase italic ml-2">Categoria</label>
                                     <select className="w-full bg-slate-50 px-5 py-4 rounded-2xl font-black text-xs outline-none border-2 border-transparent focus:border-indigo-500 italic shadow-inner" value={service.category} onChange={e => updateOutsourced(service.id, 'category', e.target.value)}>
                                        {outsourcedCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                                     </select>
                                  </div>
                                  <div className="flex-1">
                                     <label className="text-[9px] font-black text-slate-400 uppercase italic ml-2">Fase Atual</label>
                                     <select className="w-full bg-slate-50 px-5 py-4 rounded-2xl font-black text-xs outline-none border-2 border-transparent focus:border-indigo-500 italic shadow-inner" value={service.status} onChange={e => updateOutsourced(service.id, 'status', e.target.value)}>
                                        <option value="Pendente">Aguardando Produção</option>
                                        <option value="Pedido">Cotação Realizada</option>
                                        <option value="Pronto">Retornado para Fábrica</option>
                                     </select>
                                  </div>
                               </div>
                               <div>
                                  <label className="text-[9px] font-black text-slate-400 uppercase italic ml-2 flex items-center gap-2"><Building2 size={12}/> Empresa Terceirizada (Opcional na abertura)</label>
                                  <input type="text" className="w-full bg-slate-50 px-5 py-4 rounded-2xl font-black text-xs outline-none border-2 border-transparent focus:border-indigo-500 shadow-inner italic" value={service.supplierName} onChange={e => updateOutsourced(service.id, 'supplierName', e.target.value)} placeholder="Ex: Vidraçaria Avenida" />
                               </div>
                               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div>
                                     <label className="text-[9px] font-black text-slate-400 uppercase italic ml-2">Valor Estimado/Real R$</label>
                                     <input type="number" className="w-full bg-slate-50 px-5 py-4 rounded-2xl font-black text-sm text-indigo-600 outline-none border-2 border-transparent focus:border-indigo-500 shadow-inner" value={service.value} onChange={e => updateOutsourced(service.id, 'value', Number(e.target.value))} placeholder="0,00" />
                                  </div>
                                  <div className="flex items-end">
                                     <input type="text" className="w-full bg-slate-50 px-5 py-4 rounded-2xl font-bold text-xs outline-none border-2 border-transparent focus:border-indigo-500 shadow-inner italic" value={service.description} onChange={e => updateOutsourced(service.id, 'description', e.target.value)} placeholder="Breve descrição do serviço..." />
                                  </div>
                               </div>
                            </div>
                         </div>
                      ))}
                      {formData.outsourcedServices.length === 0 && (
                        <div className="col-span-full py-16 text-center border-2 border-dashed rounded-[48px] border-slate-200">
                           <Palette size={40} className="text-slate-200 mx-auto mb-4" />
                           <p className="text-[10px] text-slate-300 font-black uppercase italic tracking-[0.3em]">Nenhum serviço externo previsto inicialmente.</p>
                        </div>
                      )}
                   </div>
                </div>

                <div className="pt-12 border-t flex justify-end gap-6">
                   <button type="button" onClick={() => setIsModalOpen(false)} className="px-10 py-5 text-slate-400 font-black uppercase tracking-widest text-xs italic">Cancelar Operação</button>
                   <button type="submit" className="bg-slate-900 text-white px-16 py-6 rounded-[32px] font-black uppercase tracking-[0.3em] hover:bg-amber-500 hover:text-slate-900 shadow-2xl transition-all active:scale-95 flex items-center gap-4"><Save size={24}/> Criar OS & Iniciar Fluxo</button>
                </div>
             </form>
          </div>
        </div>
      )}

      {/* MODAL GESTÃO DE CATEGORIAS TERCEIRIZADAS */}
      {isManagingCats && (
         <div className="fixed inset-0 z-[250] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setIsManagingCats(false)} />
            <div className="relative bg-white w-full max-w-md rounded-[40px] shadow-2xl p-10 animate-in zoom-in-95">
               <div className="flex justify-between items-center mb-8">
                  <h4 className="text-xl font-black uppercase italic tracking-tight">Categorias de Terceiros</h4>
                  <button onClick={() => setIsManagingCats(false)} className="p-2 hover:bg-slate-100 rounded-full"><X/></button>
               </div>
               <div className="space-y-4 mb-8">
                  {outsourcedCategories.map(cat => (
                     <div key={cat} className="flex justify-between items-center p-4 bg-slate-50 rounded-2xl font-black uppercase italic text-[10px] tracking-widest">
                        {cat}
                        <button onClick={() => setOutsourcedCategories(p => p.filter(c => c !== cat))} className="text-slate-300 hover:text-red-500"><Trash2 size={14}/></button>
                     </div>
                  ))}
               </div>
               <div className="flex gap-2">
                  <input type="text" className="flex-1 bg-slate-100 px-5 py-3 rounded-xl font-bold text-xs outline-none focus:bg-white border-2 border-transparent focus:border-amber-500" value={newCatName} onChange={e => setNewCatName(e.target.value)} placeholder="Ex: Vidraçaria, Portas..." />
                  <button onClick={() => { if(newCatName){ setOutsourcedCategories(p => [...p, newCatName]); setNewCatName(''); } }} className="bg-slate-900 text-white p-3 rounded-xl hover:bg-amber-500 hover:text-slate-900 transition-all shadow-lg"><Plus size={20}/></button>
               </div>
            </div>
         </div>
      )}

      {/* MODAL DETALHES / FINANCEIRO */}
      {currentViewedProject && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
           <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-xl" onClick={() => setSelectedProjectId(null)} />
           <div className="relative bg-white w-full max-w-6xl h-[90vh] rounded-[56px] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95">
              <div className="p-12 bg-slate-50 border-b flex flex-col md:flex-row justify-between items-center gap-8">
                 <div>
                    <h4 className="text-4xl font-black uppercase italic tracking-tighter text-slate-900 leading-none">{currentViewedProject.workName}</h4>
                    <div className="flex gap-10 mt-8">
                       <button onClick={() => setActiveDetailTab('memorial')} className={`text-[11px] font-black uppercase tracking-[0.3em] pb-4 border-b-4 transition-all italic ${activeDetailTab === 'memorial' ? 'text-amber-500 border-amber-500' : 'text-slate-400 border-transparent'}`}>Dossiê Técnico</button>
                       <button onClick={() => setActiveDetailTab('financeiro')} className={`text-[11px] font-black uppercase tracking-[0.3em] pb-4 border-b-4 transition-all italic ${activeDetailTab === 'financeiro' ? 'text-amber-500 border-amber-500' : 'text-slate-400 border-transparent'}`}>DRE Industrial Real</button>
                    </div>
                 </div>
                 <button onClick={() => setSelectedProjectId(null)} className="p-5 hover:bg-slate-200 rounded-full transition-all text-slate-400"><X size={40}/></button>
              </div>

              <div className="flex-1 overflow-y-auto p-12 bg-white custom-scrollbar">
                {activeDetailTab === 'memorial' ? (
                   <div className="space-y-12">
                      {currentViewedProject.environmentsDetails.map(env => (
                         <div key={env.name} className="bg-slate-50 p-12 rounded-[56px] border shadow-sm space-y-10 group">
                            <div className="flex items-center gap-4 border-b pb-6">
                               <div className="w-16 h-16 bg-slate-900 text-amber-500 rounded-2xl flex items-center justify-center font-black shadow-lg"><Layers size={32}/></div>
                               <div>
                                  <h5 className="text-3xl font-black uppercase italic tracking-tighter text-slate-900 leading-none">{env.name}</h5>
                                  <p className="text-[10px] font-black text-slate-400 uppercase italic tracking-widest mt-2">Especificação Técnica Detalhada</p>
                               </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                               <div className="space-y-4">
                                  <p className="text-[10px] font-black uppercase text-slate-400 italic tracking-[0.2em] flex items-center gap-2"><Boxes size={14}/> MDF & Painéis</p>
                                  {(env.memorial?.mdfParts || []).map(part => (
                                     <div key={part.id} className="bg-white p-5 rounded-3xl border shadow-sm">
                                        <p className="text-xs font-black uppercase italic text-slate-800">{part.partName}</p>
                                        <p className="text-[10px] font-bold text-slate-500 mt-1">{part.brandColor} • {part.thickness}</p>
                                     </div>
                                  ))}
                               </div>
                               <div className="space-y-4">
                                  <p className="text-[10px] font-black uppercase text-slate-400 italic tracking-[0.2em] flex items-center gap-2"><Settings2 size={14}/> Ferragens</p>
                                  {(env.memorial?.hardwareItems || []).map(hw => (
                                     <div key={hw.id} className="bg-white p-5 rounded-3xl border shadow-sm">
                                        <p className="text-xs font-black uppercase italic text-slate-800">{hw.category}</p>
                                        <p className="text-[10px] font-bold text-slate-500 mt-1">{hw.brand} {hw.model}</p>
                                     </div>
                                  ))}
                               </div>
                               <div className="space-y-4">
                                  <p className="text-[10px] font-black uppercase text-slate-400 italic tracking-[0.2em] flex items-center gap-2"><Power size={14}/> Eletros</p>
                                  {(env.memorial?.appliances || []).map(ap => (
                                     <div key={ap.id} className="bg-white p-5 rounded-3xl border shadow-sm">
                                        <p className="text-xs font-black uppercase italic text-slate-800">{ap.item}</p>
                                        <p className="text-[10px] font-bold text-slate-500 mt-1">{ap.brandModel} • {ap.voltage}</p>
                                     </div>
                                  ))}
                               </div>
                            </div>
                         </div>
                      ))}
                      {/* Visualização de Terceiros */}
                      <div className="bg-indigo-50/50 p-12 rounded-[56px] border border-indigo-100 space-y-8">
                         <h5 className="text-2xl font-black uppercase italic tracking-tighter text-indigo-900 border-b-2 border-indigo-200 pb-4">Serviços Externos Contratados</h5>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {(currentViewedProject.outsourcedServices || []).map(s => (
                               <div key={s.id} className="bg-white p-8 rounded-[32px] border flex justify-between items-center shadow-sm">
                                  <div>
                                     <div className="flex items-center gap-2 mb-2">
                                        <p className="text-[10px] font-black text-indigo-500 uppercase italic tracking-widest leading-none">{s.category}</p>
                                        <span className={`text-[8px] font-black uppercase px-3 py-1 rounded-full ${s.status === 'Pronto' ? 'bg-emerald-50 text-white' : 'bg-amber-100 text-amber-700'}`}>{s.status}</span>
                                     </div>
                                     <h6 className="text-base font-black uppercase italic text-slate-800">{s.supplierName || 'Empresa a Definir'}</h6>
                                     <p className="text-[10px] font-bold text-slate-400 mt-1 italic">{s.description || 'Sem observações extras'}</p>
                                  </div>
                                  <div className="text-right">
                                     <p className="text-2xl font-black text-indigo-600 italic tracking-tighter leading-none">R$ {s.value?.toLocaleString()}</p>
                                     <p className="text-[9px] font-bold text-slate-400 uppercase mt-1">Custo Projetado</p>
                                  </div>
                               </div>
                            ))}
                         </div>
                      </div>
                   </div>
                ) : (
                   <div className="space-y-12">
                      {(() => {
                        const fin = calculateFinancials(currentViewedProject);
                        return (
                          <div className="space-y-12">
                             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                <div className="bg-slate-900 p-12 rounded-[56px] text-white shadow-2xl relative overflow-hidden">
                                   <div className="absolute top-0 right-0 p-8 opacity-5"><DollarSign size={80}/></div>
                                   <p className="text-[11px] font-black text-amber-500 uppercase tracking-[0.3em] mb-6 italic">Receita Total</p>
                                   <p className="text-5xl font-black tracking-tighter italic">R$ {fin.totalRevenue.toLocaleString()}</p>
                                </div>
                                <div className="bg-white p-12 rounded-[56px] border-2 shadow-sm relative overflow-hidden">
                                   <div className="absolute top-0 right-0 p-8 opacity-5"><TrendingDown size={80}/></div>
                                   <p className="text-[11px] font-black text-red-400 uppercase tracking-[0.3em] mb-6 italic">Custo Operacional Total</p>
                                   <p className="text-5xl font-black text-red-600 tracking-tighter italic">R$ {fin.totalCosts.toLocaleString()}</p>
                                </div>
                                <div className={`p-12 rounded-[56px] shadow-2xl relative overflow-hidden text-white transition-all ${fin.profit > 0 ? 'bg-emerald-600' : 'bg-red-600'}`}>
                                   <p className="text-[11px] font-black uppercase tracking-[0.3em] mb-6 italic">{fin.profit > 0 ? 'Resultado Líquido' : 'Déficit Industrial'}</p>
                                   <p className="text-5xl font-black tracking-tighter italic">R$ {fin.profit.toLocaleString()}</p>
                                   <p className="text-xl font-black mt-2 opacity-80">{fin.margin.toFixed(1)}% de Margem Bruta</p>
                                </div>
                             </div>
                             
                             <div className="bg-white rounded-[56px] border-2 overflow-hidden shadow-sm">
                                <table className="w-full text-left">
                                   <thead className="bg-slate-900 text-white">
                                      <tr>
                                         <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest italic">Referência</th>
                                         <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest italic">Descrição do Custo</th>
                                         <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest italic text-right">Valor Líquido</th>
                                      </tr>
                                   </thead>
                                   <tbody className="divide-y divide-slate-50">
                                      {/* CUSTOS DIRETOS */}
                                      {(currentViewedProject.expenses || []).map(exp => (
                                         <tr key={exp.id} className="hover:bg-slate-50">
                                            <td className="px-10 py-6 text-xs font-black text-slate-400 italic">{new Date(exp.date).toLocaleDateString()}</td>
                                            <td className="px-10 py-6 font-black uppercase italic text-sm text-slate-900">{exp.description} <span className="text-[9px] bg-slate-100 px-3 py-1 rounded-full text-slate-500 ml-2 italic">Fábrica</span></td>
                                            <td className="px-10 py-6 text-right font-black text-red-500 italic">R$ {exp.value.toLocaleString()}</td>
                                         </tr>
                                      ))}
                                      {/* CUSTOS DE SERVIÇOS TERCEIRIZADOS */}
                                      {(currentViewedProject.outsourcedServices || []).map(s => (
                                         <tr key={s.id} className="hover:bg-indigo-50/30">
                                            <td className="px-10 py-6 text-xs font-black text-indigo-400 italic">Contrato Externo</td>
                                            <td className="px-10 py-6 font-black uppercase italic text-sm text-indigo-900">{s.category}: {s.supplierName || 'A DEFINIR'} <span className="text-[9px] bg-indigo-100 px-3 py-1 rounded-full text-indigo-500 ml-2 italic">Terceirizado</span></td>
                                            <td className="px-10 py-6 text-right font-black text-red-400 italic">R$ {s.value?.toLocaleString()}</td>
                                         </tr>
                                      ))}
                                   </tbody>
                                </table>
                             </div>
                          </div>
                        );
                      })()}
                   </div>
                )}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default ObrasView;
