
import React, { useState, useEffect } from 'react';
import { Project, ChecklistItem, QualityReport, Installer } from '../types';
import { AXES, INITIAL_CHECKLIST } from '../mockData';
import { Check, X, Camera, ShieldCheck, Trophy, Sparkles, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  installers: Installer[];
  setInstallers: React.Dispatch<React.SetStateAction<Installer[]>>;
}

const QualityView: React.FC<Props> = ({ projects, setProjects, installers, setInstallers }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [checklist, setChecklist] = useState<ChecklistItem[]>(INITIAL_CHECKLIST.items);
  const [score, setScore] = useState(10);
  const [bonus, setBonus] = useState(0);
  const [isFinishing, setIsFinishing] = useState(false);

  useEffect(() => {
    setChecklist(INITIAL_CHECKLIST.items.map(item => ({ ...item, passed: null })));
  }, [selectedProject?.id]);

  const calculateResults = (items: ChecklistItem[]) => {
    const totalItems = items.length;
    const passedItems = items.filter(i => i.passed === true).length;
    const answeredItems = items.filter(i => i.passed !== null).length;
    
    if (answeredItems === 0) return { score: 10, bonus: 0 };
    
    const newScore = (passedItems / totalItems) * 10;
    const baseBonus = 500; 
    const newBonus = newScore === 10 ? baseBonus : (newScore >= 8 ? baseBonus * 0.5 : 0);
    
    return { score: Number(newScore.toFixed(1)), bonus: newBonus };
  };

  const handleToggle = (id: string, passed: boolean) => {
    const updated = checklist.map(item => item.id === id ? { ...item, passed } : item);
    setChecklist(updated);
    const results = calculateResults(updated);
    setScore(results.score);
    setBonus(results.bonus);
  };

  const handleFinishInspection = () => {
    if (!selectedProject) return;

    const unanswered = checklist.filter(i => i.passed === null);
    if (unanswered.length > 0) {
      alert(`AUDITORIA INCOMPLETA!\n\nRestam ${unanswered.length} itens a serem verificados antes da finalização.`);
      return;
    }

    setIsFinishing(true);

    // 1. Atualizar Status do Projeto
    setProjects(prev => prev.map(p => {
      if (p.id === selectedProject.id) {
        return {
          ...p,
          currentStatus: 'Finalizada',
          history: [...p.history, { status: 'Finalizada', timestamp: new Date().toISOString() }]
        };
      }
      return p;
    }));

    // 2. Processar Bônus e Métrica do Montador
    const installerIds = Array.from(new Set(selectedProject.environmentsDetails.map(e => e.assignedInstallerId).filter(Boolean)));
    
    setInstallers(prev => prev.map(inst => {
      if (installerIds.includes(inst.id)) {
        const newCount = inst.installationsCount + 1;
        const newAverage = ((inst.averageRating * (inst.installationsCount || 0)) + score) / newCount;
        return {
          ...inst,
          installationsCount: newCount,
          averageRating: Number(newAverage.toFixed(1)),
          totalBonus: inst.totalBonus + bonus
        };
      }
      return inst;
    }));

    setTimeout(() => {
      alert(`AUDITORIA FINALIZADA!\n\nScore: ${score}/10\nBônus Gerado: R$ ${bonus.toFixed(2)}\nO projeto foi arquivado.`);
      setIsFinishing(false);
      setSelectedProject(null);
    }, 1500);
  };

  const resetForm = () => {
    setSelectedProject(null);
    setScore(10);
    setBonus(0);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between no-print">
        <div>
          <h3 className="text-2xl font-black text-slate-800 uppercase italic tracking-tight">Qualidade & Encerramento</h3>
          <p className="text-slate-500 font-bold text-sm uppercase italic">Auditoria Técnica de Acabamento e Mão de Obra</p>
        </div>
        {selectedProject && (
          <button onClick={resetForm} className="text-slate-400 hover:text-red-500 font-black uppercase text-[10px] tracking-widest border border-slate-200 px-5 py-2.5 rounded-xl transition-all">
             Cancelar Vistoria
          </button>
        )}
      </div>

      {!selectedProject ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.filter(p => p.currentStatus === 'Instalação').map(project => (
            <button 
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className="p-8 bg-white border border-slate-200 rounded-[32px] text-left hover:border-amber-500 transition-all shadow-sm group active:scale-[0.98]"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="p-4 bg-slate-900 text-amber-500 rounded-2xl group-hover:bg-amber-500 group-hover:text-slate-900 transition-all shadow-lg">
                  <ShieldCheck size={28} />
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-100 italic">Vistoria Requerida</span>
                </div>
              </div>
              <h4 className="text-2xl font-black text-slate-900 uppercase italic tracking-tighter leading-none mb-2">{project.workName}</h4>
              <p className="text-xs text-slate-500 font-black uppercase tracking-widest italic">{project.clientName}</p>
            </button>
          ))}
          {projects.filter(p => p.currentStatus === 'Instalação').length === 0 && (
            <div className="col-span-full py-24 text-center bg-slate-50 border border-dashed border-slate-200 rounded-[40px] opacity-60">
              <Check size={48} className="text-slate-200 mx-auto mb-4" />
              <p className="text-slate-400 font-black uppercase italic text-sm tracking-widest">Aguardando obras em fase de montagem final...</p>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-[40px] border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500">
          <div className="bg-slate-900 text-white p-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div>
                <span className="bg-amber-500 text-slate-900 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest mb-4 inline-block italic shadow-lg">Checklist Final</span>
                <h4 className="text-3xl font-black uppercase italic tracking-tighter leading-none">{selectedProject.workName}</h4>
              </div>
              <div className="bg-white/5 p-6 rounded-[32px] border border-white/10 text-right min-w-[200px]">
                <div className="flex items-center gap-3 text-amber-500 mb-1 justify-end">
                  <Trophy size={28} />
                  <span className="text-6xl font-black tracking-tighter italic">{score}</span>
                </div>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest italic mt-2">Bônus MDO: R$ {bonus.toFixed(2)}</p>
              </div>
            </div>
          </div>

          <div className="p-10 space-y-12 bg-slate-50/20">
            {AXES.map(axis => (
              <div key={axis} className="space-y-6">
                <h5 className="font-black text-slate-900 text-[10px] uppercase tracking-[0.3em] border-b-2 border-slate-900 pb-3 italic">{axis}</h5>
                <div className="grid grid-cols-1 gap-4">
                  {checklist.filter(item => item.axis === axis).map(item => (
                    <div key={item.id} className={`flex items-center justify-between p-6 bg-white rounded-[24px] border transition-all ${item.passed === null ? 'border-slate-100' : (item.passed ? 'border-emerald-500/30' : 'border-red-500/30')}`}>
                      <span className="font-black text-slate-800 uppercase italic text-sm tracking-tight">{item.label}</span>
                      <div className="flex gap-3">
                        <button onClick={() => handleToggle(item.id, true)} className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${item.passed === true ? 'bg-emerald-600 text-white shadow-xl' : 'bg-slate-50 text-slate-300'}`}><Check size={28}/></button>
                        <button onClick={() => handleToggle(item.id, false)} className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${item.passed === false ? 'bg-red-600 text-white shadow-xl' : 'bg-slate-50 text-slate-300'}`}><X size={28}/></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <button 
              onClick={handleFinishInspection}
              disabled={isFinishing}
              className="w-full py-8 bg-slate-900 text-white font-black uppercase tracking-[0.2em] rounded-[32px] transition-all shadow-2xl flex items-center justify-center gap-4 hover:bg-amber-500 hover:text-slate-900 active:scale-95 disabled:opacity-50"
            >
              {isFinishing ? <RefreshCw className="animate-spin" size={28}/> : <><ShieldCheck size={32} /> Finalizar Auditoria & Liberar Bônus</>}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default QualityView;
