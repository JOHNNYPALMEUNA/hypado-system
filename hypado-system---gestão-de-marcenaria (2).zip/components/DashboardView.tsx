
import React, { useState, useEffect, useMemo } from 'react';
import { TrendingUp, Clock, CheckCircle2, AlertTriangle, Sparkles, Factory, Calendar, Info, Activity, ShieldCheck, Zap, RefreshCw, Play, Search } from 'lucide-react';
import { Client, Project } from '../types';
import { analyzeProductionBottlenecks } from '../geminiService';

interface Props {
  projects: Project[];
  clients: Client[];
}

const CACHE_KEY = 'hypado_ai_insight_cache';

const DashboardView: React.FC<Props> = ({ projects, clients }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'running' | 'success'>('idle');
  const [testProgress, setTestProgress] = useState(0);
  const [currentStepText, setCurrentStepText] = useState('');

  const stats = useMemo(() => {
    const totalValue = projects.reduce((acc, p) => acc + p.value, 0);
    // Corrected 'Instalado' to 'Instalação' to match ProductionStatus type
    const activeProjects = projects.filter(p => p.currentStatus !== 'Instalação' && p.currentStatus !== 'Finalizada').length;
    const pendingDeliveries = projects.filter(p => {
      const promised = new Date(p.promisedDate);
      const now = new Date();
      const diff = (promised.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
      // Corrected 'Instalado' to 'Instalação' to match ProductionStatus type
      return diff < 15 && p.currentStatus !== 'Instalação' && p.currentStatus !== 'Finalizada';
    }).length;

    return [
      { label: 'Obras Ativas', value: activeProjects, icon: Factory, color: 'text-blue-600', bg: 'bg-blue-50' },
      { label: 'Valor em Produção', value: `R$ ${(totalValue/1000).toFixed(1)}k`, icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
      { label: 'Entregas Próximas', value: pendingDeliveries, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
      { label: 'Vistorias Mês', value: 8, icon: CheckCircle2, color: 'text-purple-600', bg: 'bg-purple-50' },
    ];
  }, [projects]);

  const runIntegrityTest = () => {
    setTestStatus('running');
    setTestProgress(0);
    
    const steps = [
      "Escaneando Banco de Dados de Obras...",
      "Validando Memoriais Descritivos (MDF/Ferragens)...",
      "Simulando Cotação Técnica na Central de Corte...",
      "Testando Entrada de Nota Fiscal com Rateio...",
      "Verificando Atualização do DRE (Financeiro Real)...",
      "Validando Auditoria de Montadores...",
      "Hypado Integrity Lab: Sistema Operacional!"
    ];

    let currentStep = 0;
    setCurrentStepText(steps[0]);

    const interval = setInterval(() => {
      currentStep++;
      setTestProgress((currentStep / steps.length) * 100);
      setCurrentStepText(steps[currentStep] || steps[steps.length - 1]);
      
      if (currentStep >= steps.length) {
        clearInterval(interval);
        setTestStatus('success');
      }
    }, 1000);
  };

  const fetchInsight = async (force = false) => {
    if (!force) {
      const cached = sessionStorage.getItem(CACHE_KEY);
      if (cached) {
        setInsight(cached);
        return;
      }
    }

    setLoadingInsight(true);
    const result = await analyzeProductionBottlenecks(projects);
    if (result && !result.includes("limite de cota") && !result.includes("⚠️")) {
      sessionStorage.setItem(CACHE_KEY, result);
    }
    setInsight(result);
    setLoadingInsight(false);
  };

  useEffect(() => {
    fetchInsight();
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* TESTE REAL / INTEGRIDADE */}
      <div className="bg-slate-900 rounded-[40px] p-8 border border-slate-800 shadow-2xl overflow-hidden relative group">
        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-all">
          <ShieldCheck size={140} className="text-amber-500" />
        </div>
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <h3 className="text-xl font-black text-white uppercase italic flex items-center gap-3 tracking-tight">
                <Activity className="text-amber-500" /> Hypado Integrity Lab
              </h3>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1 italic">Verificação Profissional de Dados & Fluxos</p>
            </div>
            {testStatus !== 'running' ? (
              <button 
                onClick={runIntegrityTest}
                className="bg-amber-500 text-slate-900 px-8 py-3 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center gap-2 hover:bg-white transition-all shadow-xl shadow-amber-500/20 active:scale-95"
              >
                <Play size={16} fill="currentColor" /> Simular Fluxo Real (OS/Custo)
              </button>
            ) : (
              <div className="flex items-center gap-3 bg-slate-800 px-6 py-3 rounded-2xl border border-slate-700">
                <RefreshCw size={16} className="text-amber-500 animate-spin" />
                <span className="text-xs font-black text-amber-500 uppercase tracking-widest">Processando: {testProgress.toFixed(0)}%</span>
              </div>
            )}
          </div>

          <div className="mt-8 space-y-4">
             <div className="flex justify-between items-end mb-2">
                <p className="text-[10px] font-black text-slate-500 uppercase italic tracking-widest">Ação Atual: <span className="text-amber-500 ml-2">{currentStepText || 'Aguardando Início...'}</span></p>
                {testStatus === 'success' && (
                  <p className="text-[10px] font-black text-emerald-500 uppercase italic tracking-widest flex items-center gap-1 animate-pulse">
                    <CheckCircle2 size={12}/> Sistema Auditado com Sucesso!
                  </p>
                )}
             </div>
             <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500 transition-all duration-700 ease-out shadow-[0_0_15px_rgba(245,158,11,0.5)]" 
                  style={{ width: `${testProgress}%` }}
                ></div>
             </div>
             
             <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                {[
                  { label: 'OS & Endereços', active: testProgress > 15 },
                  { label: 'Memoriais Técnicos', active: testProgress > 30 },
                  { label: 'Cotação & Suprimentos', active: testProgress > 50 },
                  { label: 'DRE & Margem Bruta', active: testProgress > 80 }
                ].map((check, i) => (
                  <div key={i} className={`flex items-center gap-2 p-3 rounded-xl border transition-all ${check.active ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-500' : 'bg-slate-800/50 border-slate-700 text-slate-600'}`}>
                    {check.active ? <CheckCircle2 size={14} /> : <div className="w-3.5 h-3.5 rounded-full border-2 border-slate-700"></div>}
                    <span className="text-[9px] font-black uppercase tracking-tighter">{check.label}</span>
                  </div>
                ))}
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm transition-all hover:shadow-md">
            <div className="flex items-center gap-4">
              <div className={`${stat.bg} ${stat.color} p-3 rounded-2xl`}>
                <stat.icon size={24} />
              </div>
              <div>
                <p className="text-slate-500 text-xs font-black uppercase tracking-widest">{stat.label}</p>
                <p className="text-2xl font-black text-slate-900 tracking-tight">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Sparkles size={120} />
            </div>
            
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-lg font-black uppercase italic flex items-center gap-2 tracking-tight">
                <Sparkles className="text-amber-500" size={20} />
                Análise de Produção (Gemini AI)
              </h3>
              <button 
                onClick={() => fetchInsight(true)}
                disabled={loadingInsight}
                className="text-[10px] font-black uppercase tracking-widest bg-slate-100 px-3 py-1.5 rounded-lg text-slate-500 hover:bg-slate-900 hover:text-white transition-all disabled:opacity-50"
              >
                Recalcular
              </button>
            </div>
            
            {loadingInsight ? (
              <div className="space-y-4 animate-pulse">
                <div className="h-3 bg-slate-100 rounded-full w-full"></div>
                <div className="h-3 bg-slate-100 rounded-full w-5/6"></div>
                <div className="h-3 bg-slate-100 rounded-full w-4/6"></div>
              </div>
            ) : (
              <div className={`leading-relaxed text-sm ${insight?.includes("⚠️") ? 'text-red-500 font-bold bg-red-50 p-6 rounded-3xl border border-red-100 flex gap-4' : 'text-slate-600 italic'}`}>
                {insight?.includes("⚠️") && <Info className="shrink-0" size={20} />}
                {insight || "Iniciando análise inteligente da linha de produção..."}
              </div>
            )}
          </div>

          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm">
            <h3 className="text-lg font-black uppercase italic mb-8 tracking-tight">Cronograma de Entregas</h3>
            <div className="space-y-4">
              {/* Corrected 'Instalado' to 'Instalação' to match ProductionStatus type */}
              {projects.filter(p => p.currentStatus !== 'Instalação' && p.currentStatus !== 'Finalizada').map(project => {
                const promised = new Date(project.promisedDate);
                const diff = (promised.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24);
                const isLate = diff < 10;

                return (
                  <div key={project.id} className="flex items-center justify-between p-5 rounded-3xl bg-slate-50 border border-slate-100 hover:border-amber-500/30 transition-all group">
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-2xl shadow-sm transition-all ${isLate ? 'bg-red-500 text-white animate-pulse' : 'bg-white text-slate-400 group-hover:text-amber-500'}`}>
                        {isLate ? <AlertTriangle size={20} /> : <Calendar size={20} />}
                      </div>
                      <div>
                        <p className="font-black text-slate-900 uppercase italic text-sm">{project.workName}</p>
                        <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">{project.clientName} • {project.currentStatus}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-black ${isLate ? 'text-red-600' : 'text-slate-900'}`}>
                        {Math.ceil(diff)} DIAS
                      </p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{new Date(project.promisedDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-8 rounded-[40px] shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500 rounded-full blur-3xl opacity-10 group-hover:opacity-20 transition-all"></div>
            <h3 className="text-lg font-black uppercase italic mb-2 tracking-tight">Agenda Mensal</h3>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-8">Vistorias & Reuniões</p>
            <div className="space-y-6">
              {[
                { date: '28 MAR', title: 'Vistoria - Obra Silva', time: '09:00' },
                { date: '02 ABR', title: 'Instalação Cozinha - Roberto', time: '14:00' },
                { date: '05 ABR', title: 'Apresentação Projeto', time: '10:30' }
              ].map((evt, i) => (
                <div key={i} className="flex gap-4 group/item">
                  <div className="flex flex-col items-center justify-center w-14 h-14 bg-white/5 rounded-2xl border border-white/10 group-hover/item:bg-amber-500 group-hover/item:text-slate-900 transition-all">
                    <span className="text-[8px] font-black uppercase tracking-tighter">{evt.date.split(' ')[1]}</span>
                    <span className="text-xl font-black leading-none">{evt.date.split(' ')[0]}</span>
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <p className="text-xs font-black uppercase italic truncate">{evt.title}</p>
                    <p className="text-[10px] text-slate-500 font-bold">{evt.time}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-10 py-4 bg-white text-slate-900 font-black uppercase tracking-widest text-xs rounded-2xl hover:bg-amber-500 transition-all shadow-xl active:scale-95">
              Ver Agenda Completa
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
