
import React, { useMemo } from 'react';
import { Project } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';

interface Props {
  projects: Project[];
}

const COLORS = ['#f59e0b', '#10b981', '#6366f1', '#f43f5e', '#64748b'];

const AnalyticsView: React.FC<Props> = ({ projects }) => {
  const statusData = useMemo(() => {
    const counts = projects.reduce((acc, p) => {
      acc[p.currentStatus] = (acc[p.currentStatus] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [projects]);

  const teamPerformance = useMemo(() => [
    { team: 'Equipe Alfa', score: 9.6, quality: 98 },
    { team: 'Equipe Beta', score: 8.9, quality: 85 },
    { team: 'Equipe Gama', score: 9.2, quality: 90 },
    { team: 'Equipe Delta', score: 7.8, quality: 72 },
  ], []);

  const leadTimeEvolution = useMemo(() => [
    { month: 'Jan', time: 45 },
    { month: 'Fev', time: 42 },
    { month: 'Mar', time: 38 },
    { month: 'Abr', time: 35 },
  ], []);

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-slate-800">BI & Inteligência</h3>
        <p className="text-slate-500">Decisões baseadas em dados para marcenaria de alto desempenho.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Distribuição de Produção */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Distribuição por Status</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-6">
            {statusData.map((d, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                <span className="text-xs font-medium text-slate-600">{d.name}: <strong>{d.value}</strong></span>
              </div>
            ))}
          </div>
        </div>

        {/* Ranking de Equipes */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Ranking de Qualidade (Equipes)</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={teamPerformance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                <XAxis type="number" hide />
                <YAxis dataKey="team" type="category" width={100} tick={{ fontSize: 12, fontWeight: 600 }} />
                <Tooltip cursor={{ fill: '#f8fafc' }} />
                <Bar dataKey="score" fill="#f59e0b" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-slate-400 italic mt-4">* Nota média baseada nos últimos 10 checklists realizados.</p>
        </div>

        {/* Evolução de Lead Time */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Evolução do Lead Time (Dias)</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={leadTimeEvolution}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Line type="monotone" dataKey="time" stroke="#6366f1" strokeWidth={3} dot={{ r: 6, fill: '#6366f1' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Matriz de Erros Recorrentes */}
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Matriz de Defeitos Recorrentes</h4>
          <div className="space-y-4">
            {[
              { label: 'Ajuste de Prumo/Nível', count: 12, color: 'bg-red-500' },
              { label: 'Limpeza Interna', count: 8, color: 'bg-amber-500' },
              { label: 'Siliconamento Falho', count: 5, color: 'bg-blue-500' },
              { label: 'Amortecimento de Corrediças', count: 3, color: 'bg-emerald-500' },
            ].map((item, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold uppercase tracking-tight">
                  <span className="text-slate-600">{item.label}</span>
                  <span className="text-slate-900">{item.count} ocorrências</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`${item.color} h-full transition-all duration-1000`} 
                    style={{ width: `${(item.count/15)*100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsView;
