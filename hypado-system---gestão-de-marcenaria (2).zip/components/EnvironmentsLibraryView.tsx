
import React, { useState } from 'react';
import { Environment } from '../types';
import { Plus, Trash2, Layers, Search, X } from 'lucide-react';

interface Props {
  environments: Environment[];
  setEnvironments: React.Dispatch<React.SetStateAction<Environment[]>>;
}

const EnvironmentsLibraryView: React.FC<Props> = ({ environments, setEnvironments }) => {
  const [newEnvName, setNewEnvName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEnvName.trim()) return;
    
    const newEnv: Environment = {
      id: `e-${Date.now()}`,
      name: newEnvName.trim()
    };
    
    setEnvironments(prev => [...prev, newEnv]);
    setNewEnvName('');
  };

  const handleDelete = (id: string) => {
    if (confirm('Deseja remover este ambiente da biblioteca? Isso não afetará obras já criadas.')) {
      setEnvironments(prev => prev.filter(e => e.id !== id));
    }
  };

  const filtered = environments.filter(e => e.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h3 className="text-2xl font-bold text-slate-800">Biblioteca de Ambientes</h3>
        <p className="text-slate-500">Gerencie os tipos de ambientes que sua marcenaria produz.</p>
      </div>

      <form onSubmit={handleAdd} className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm flex gap-3">
        <input 
          type="text" 
          value={newEnvName}
          onChange={(e) => setNewEnvName(e.target.value)}
          placeholder="Ex: Closet Master, Cozinha Ilha..." 
          className="flex-1 px-4 py-3 bg-slate-50 border-2 border-transparent focus:border-amber-500/30 rounded-2xl outline-none"
          required
        />
        <button type="submit" className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-800 transition-all">
          <Plus size={20} /> Adicionar
        </button>
      </form>

      <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <Search size={20} className="text-slate-400" />
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Pesquisar na biblioteca..." 
            className="flex-1 bg-transparent outline-none text-sm font-medium"
          />
        </div>
        <div className="divide-y divide-slate-50">
          {filtered.map(env => (
            <div key={env.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
                  <Layers size={18} />
                </div>
                <span className="font-bold text-slate-700">{env.name}</span>
              </div>
              <button 
                onClick={() => handleDelete(env.id)}
                className="p-2 text-slate-300 hover:text-red-500 transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="p-12 text-center">
              <p className="text-slate-400 italic">Nenhum ambiente encontrado.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnvironmentsLibraryView;
