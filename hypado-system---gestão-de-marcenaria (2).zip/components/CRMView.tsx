
import React, { useState } from 'react';
import { Client, Project } from '../types';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Star, 
  Plus, 
  X, 
  Briefcase, 
  TrendingUp, 
  Loader2, 
  Edit2, 
  Trash2, 
  Ban, 
  CheckCircle2 
} from 'lucide-react';

interface Props {
  clients: Client[];
  setClients: React.Dispatch<React.SetStateAction<Client[]>>;
  projects: Project[];
}

const EMAIL_DOMAINS = ['@gmail.com', '@hotmail.com', '@outlook.com', '@icloud.com'];

const CRMView: React.FC<Props> = ({ clients, setClients, projects }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isFetchingCep, setIsFetchingCep] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    cep: '',
    address: '',
    quadra: '',
    lote: '',
    description: '',
    isBlocked: false
  });

  const openModal = (client?: Client) => {
    if (client) {
      setEditingClient(client);
      setFormData({
        name: client.name || '',
        email: client.email || '',
        phone: client.phone || '',
        cep: '', 
        address: client.address || '',
        quadra: client.quadra || '',
        lote: client.lote || '',
        description: client.description || '',
        isBlocked: client.isBlocked || false
      });
    } else {
      setEditingClient(null);
      setFormData({ 
        name: '', email: '', phone: '', cep: '', address: '',
        quadra: '', lote: '', description: '', isBlocked: false
      });
    }
    setIsModalOpen(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as any;
    
    if (name === 'cep') {
      const cleanCep = value.replace(/\D/g, '').substring(0, 8);
      setFormData(prev => ({ ...prev, [name]: cleanCep }));
      if (cleanCep.length === 8) fetchAddress(cleanCep);
    } else if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const applyEmailDomain = (domain: string) => {
    setFormData(prev => {
      const currentEmail = (prev.email || '').trim();
      if (!currentEmail) return prev;
      
      const atIndex = currentEmail.indexOf('@');
      const prefix = atIndex > -1 ? currentEmail.substring(0, atIndex) : currentEmail;
      
      return { ...prev, email: `${prefix}${domain}` };
    });
  };

  const fetchAddress = async (cep: string) => {
    setIsFetchingCep(true);
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      if (!data.erro) {
        const fullAddress = `${data.logradouro}, ${data.bairro} - ${data.localidade}/${data.uf}`;
        setFormData(prev => ({ ...prev, address: fullAddress }));
      }
    } catch (error) {
      console.error("Erro ao buscar CEP:", error);
    } finally {
      setIsFetchingCep(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      alert('Por favor, preencha pelo menos o Nome e o Telefone.');
      return;
    }

    if (editingClient) {
      setClients(prev => (prev || []).map(c => c.id === editingClient.id ? {
        ...c,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        address: formData.address,
        quadra: formData.quadra,
        lote: formData.lote,
        description: formData.description,
        isBlocked: formData.isBlocked
      } : c));
    } else {
      const newClient: Client = {
        id: `c-${Date.now()}`,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        address: formData.address,
        quadra: formData.quadra,
        lote: formData.lote,
        description: formData.description,
        projectsCount: 0,
        averageRating: 0,
        lastVisit: new Date().toISOString().split('T')[0],
        isBlocked: formData.isBlocked
      };
      setClients(prev => [newClient, ...(prev || [])]);
    }

    setIsModalOpen(false);
  };

  const handleDelete = () => {
    if (!editingClient) return;
    if (confirm(`Excluir cliente ${editingClient.name}?`)) {
      setClients(prev => (prev || []).filter(c => c.id !== editingClient.id));
      setIsModalOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-2xl font-bold text-slate-800 tracking-tight">Diretório de Clientes</h3>
        </div>
        <button onClick={() => openModal()} className="bg-slate-900 text-white px-6 py-2.5 rounded-full font-bold flex items-center gap-2 hover:bg-slate-800 active:scale-95 shadow-lg"><Plus size={20} /> Novo Cliente</button>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setIsModalOpen(false)} />
          <div className="relative bg-white w-full max-w-lg rounded-[32px] shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="p-8 border-b bg-slate-50 flex justify-between items-center">
              <div>
                <h4 className="text-xl font-bold">{editingClient ? 'Editar Cliente' : 'Novo Cliente'}</h4>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-900"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-4 max-h-[80vh] overflow-y-auto">
              <input type="text" name="name" value={formData.name} onChange={handleInputChange} placeholder="Nome Completo" className="w-full px-4 py-3 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-amber-500 outline-none" required />
              <div className="grid grid-cols-2 gap-4">
                <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} placeholder="Telefone" className="w-full px-4 py-3 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-amber-500 outline-none" required />
                <input type="email" name="email" value={formData.email} onChange={handleInputChange} placeholder="E-mail" className="w-full px-4 py-3 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-amber-500 outline-none" />
              </div>
              <div className="space-y-4 pt-2 border-t">
                <input type="text" name="cep" value={formData.cep} onChange={handleInputChange} maxLength={8} placeholder="CEP" className="w-full px-4 py-3 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-amber-500 outline-none" />
                <textarea name="address" value={formData.address} onChange={handleInputChange} placeholder="Endereço Completo" className="w-full px-4 py-3 bg-slate-50 rounded-2xl border-2 border-transparent focus:border-amber-500 outline-none h-20 resize-none" />
              </div>
              <button type="submit" className="w-full py-4 bg-amber-500 text-slate-900 font-bold rounded-2xl hover:bg-amber-400 transition-all shadow-lg active:scale-95">{editingClient ? 'Salvar Alterações' : 'Salvar Cliente'}</button>
              {editingClient && <button type="button" onClick={handleDelete} className="w-full py-4 bg-red-50 text-red-600 font-bold rounded-2xl hover:bg-red-100 flex items-center justify-center gap-2"><Trash2 size={18} /> Excluir Cliente</button>}
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {(clients || []).map(client => {
          const clientProjects = (projects || []).filter(p => p.clientId === client.id);
          const totalValue = clientProjects.reduce((acc, p) => acc + (p.value || 0), 0);
          return (
            <div key={client.id} className={`bg-white rounded-[32px] border shadow-sm p-6 hover:shadow-md transition-all relative group ${client.isBlocked ? 'border-red-200' : 'border-slate-200'}`}>
              <button onClick={() => openModal(client)} className="absolute top-6 right-6 p-2 text-slate-400 hover:text-amber-500 transition-all opacity-0 group-hover:opacity-100"><Edit2 size={20} /></button>
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold ${client.isBlocked ? 'bg-red-50 text-red-400' : 'bg-slate-100 text-slate-600'}`}>{ (client.name || 'C').charAt(0) }</div>
                <div>
                  <h4 className="text-xl font-bold text-slate-900">{client.name}</h4>
                  <div className="flex items-center gap-1 text-amber-500 mt-1"><Star size={14} fill={client.averageRating > 0 ? "currentColor" : "none"} /><span className="text-sm font-bold">{client.averageRating > 0 ? `${client.averageRating}` : 'Novo'}</span></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-slate-50 p-4 rounded-2xl"><p className="text-[10px] font-bold text-slate-400 uppercase">Obras</p><p className="text-xl font-bold">{clientProjects.length}</p></div>
                <div className="bg-slate-50 p-4 rounded-2xl"><p className="text-[10px] font-bold text-slate-400 uppercase">Total</p><p className="text-xl font-bold">R$ {(totalValue/1000).toFixed(1)}k</p></div>
              </div>
              <div className="space-y-3 pt-4 border-t border-slate-50 text-sm text-slate-600">
                <div className="flex items-center gap-3"><Phone size={16} className="text-slate-400" /> {client.phone}</div>
                <div className="flex items-center gap-3"><Mail size={16} className="text-slate-400" /> {client.email || 'Não informado'}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CRMView;
