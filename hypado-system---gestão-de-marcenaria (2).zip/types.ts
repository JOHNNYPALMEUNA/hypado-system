
export type ProductionStatus = 'Projeto' | 'Corte' | 'Produção' | 'Instalação' | 'Finalizada';
export type PurchaseStatus = 'Cotação' | 'Comprado' | 'Entregue';
export type SupplierType = 'Material' | 'Serviço (Corte/Fitação)' | 'Montagem (Terceirizado)';
export type OutsourcedStatus = 'Pendente' | 'Pedido' | 'Pronto';
export type TeamRole = 'Montador' | 'Ajudante' | 'Marceneiro' | 'Freteiro' | 'Projetista';

export interface Company {
  name: string;
  cnpj: string;
  phone: string;
  email: string;
  address: string;
  logo?: string; 
}

export interface Installer {
  id: string;
  name: string;
  cpf: string;
  phone: string;
  role: TeamRole;
  status: 'Ativo' | 'Inativo' | 'Em Obra';
  specialty: string;
  observations: string;
  installationsCount: number;
  averageRating: number;
  totalBonus: number;
  defaultDailyRate?: number;
  avatar?: string;
}

export interface ProjectDiaryEntry {
  id: string;
  projectId: string;
  personId: string;
  date: string;
  value: number;
  description: string;
  role: TeamRole;
}

export interface MdfPart {
  id: string;
  partName: string;
  brandColor: string;
  thickness: string;
}

export interface Appliance {
  id: string;
  item: string; 
  brandModel: string;
  voltage: '110v' | '220v' | 'Bivolt' | 'N/A';
  needsVentilation: boolean;
  manualConfirmed: boolean;
}

export interface HardwareItem {
  id: string;
  category: string; 
  brand: string;
  model: string;
  location?: string;
  description?: string;
}

export interface OutsourcedService {
  id: string;
  category: string;
  description: string;
  status: OutsourcedStatus;
  location?: string;
  supplierId?: string;
  supplierName?: string;
  value?: number;
  orderDate?: string;
}

export interface MemorialDescritivo {
  mdfParts: MdfPart[];
  fitacao: string;
  fundo: string;
  hardwareItems: HardwareItem[];
  appliances: Appliance[];
}

export interface EnvironmentWithDetails {
  name: string;
  type: 'Cozinha' | 'Quarto' | 'Sala' | 'Banheiro' | 'Geral' | 'Lavanderia' | 'Gourmet';
  memorial: MemorialDescritivo;
  value: number; 
  assignedInstallerId?: string;
  serviceContractValue?: number;
  servicePercentage?: number; 
  manualValueOverride?: boolean;
  isMdoAuthorized?: boolean;
  authorizedMdoValue?: number;
}

export interface Expense {
  id: string;
  description: string;
  value: number;
  date: string;
  category: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  quadra?: string;
  lote?: string;
  description?: string;
  projectsCount: number;
  averageRating: number;
  lastVisit: string;
  isBlocked?: boolean; 
}

export interface Environment {
  id: string;
  name: string;
}

export interface Project {
  id: string;
  clientId: string;
  clientName: string;
  workName: string; 
  environments: string[];
  environmentsDetails: EnvironmentWithDetails[];
  contractDate: string;
  promisedDate: string;
  currentStatus: ProductionStatus;
  history: { status: ProductionStatus; timestamp: string }[];
  value: number; 
  expenses: Expense[]; 
  team: string; 
  installerId?: string; 
  workAddress: string;
  materialsDelivered?: boolean;
  productionCentral?: string;
  outsourcedServices: OutsourcedService[]; 
}

export interface Product {
  id: string;
  name: string;
  category: string;
  brand?: string;
  unit?: string;
  description?: string;
}

export type Material = Product;

export interface Supplier {
  id: string;
  name: string;
  type: SupplierType;
  contact: string;
  category?: string;
}

export interface QuotationItem {
  productId: string;
  name: string;
  quantity: number;
  unit: string;
  materialValue?: number;
  serviceValue?: number;
}

export interface Quotation {
  id: string;
  projectId: string;
  workName: string;
  supplierId: string;
  status: PurchaseStatus;
  items: QuotationItem[];
  date: string;
}

export interface ChecklistItem {
  id: string;
  axis: string;
  label: string;
  passed: boolean | null;
}

export interface QualityReport {
  id: string;
  projectId: string;
  installerId: string;
  date: string;
  score: number;
  bonusAmount: number;
  inspectorName: string;
  items: ChecklistItem[];
}
