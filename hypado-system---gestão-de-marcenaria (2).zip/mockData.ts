
import { Client, Project, QualityReport, Environment, MemorialDescritivo } from './types';

export const MOCK_ENVIRONMENTS: Environment[] = [
  { id: 'e1', name: 'Cozinha' },
  { id: 'e2', name: 'Suíte Master' },
  { id: 'e3', name: 'Closet' },
  { id: 'e4', name: 'Home Office' },
  { id: 'e5', name: 'Lavabo' },
  { id: 'e6', name: 'Área Gourmet' },
  { id: 'e7', name: 'Sala de Estar' },
];

export const MOCK_CLIENTS: Client[] = [
  {
    id: 'c1',
    name: 'Ana Silva',
    email: 'ana.silva@email.com',
    phone: '(11) 98888-7777',
    address: 'Av. Paulista, 1000 - São Paulo, SP',
    projectsCount: 3,
    averageRating: 9.5,
    lastVisit: '2024-03-15'
  }
];

const DEFAULT_MEMORIAL: MemorialDescritivo = {
  mdfParts: [
    { id: '1', partName: 'Caixaria', brandColor: 'Branco Standard', thickness: '15mm' },
    { id: '2', partName: 'Frentes', brandColor: 'Guararapes Padrão Marcenaria', thickness: '18mm' }
  ],
  fitacao: 'PVC 0.45mm',
  fundo: '6mm Branco Encaixado',
  hardwareItems: [
    { id: 'h1', category: 'Dobradiça', brand: 'Blum', model: 'Clip Top com Amortecimento' },
    { id: 'h2', category: 'Corrediça', brand: 'Blum', model: 'Tandembox Antaro Cinza' },
    { id: 'h3', category: 'Puxador', brand: 'Alumitech', model: 'Perfil Gola Bronze' }
  ],
  appliances: [
    { id: 'ap1', item: 'Forno Elétrico', brandModel: 'Brastemp Gourmand', voltage: '220v', needsVentilation: true, manualConfirmed: true }
  ]
};

// Fix: Added missing 'outsourcedServices' property to comply with Project interface
export const MOCK_PROJECTS: Project[] = [
  {
    id: 'p1',
    clientId: 'c1',
    clientName: 'Ana Silva',
    workName: 'Apto 1202 - Ed. Mirante',
    environments: ['Cozinha', 'Área Gourmet'],
    environmentsDetails: [
      { name: 'Cozinha', type: 'Cozinha', memorial: DEFAULT_MEMORIAL, value: 25000 },
      { name: 'Área Gourmet', type: 'Gourmet', memorial: DEFAULT_MEMORIAL, value: 20000 }
    ],
    contractDate: '2024-01-10',
    promisedDate: '2024-04-10',
    currentStatus: 'Projeto',
    value: 45000,
    team: 'Equipe Alfa',
    workAddress: 'Av. Paulista, 1000 - São Paulo, SP',
    expenses: [],
    history: [
      { status: 'Projeto', timestamp: '2024-01-12T10:00:00Z' }
    ],
    materialsDelivered: false, // Inicia bloqueado para o PCP testar a trava
    outsourcedServices: []
  }
];

export const AXES = ['Estrutura', 'Funcionamento', 'Portas de Correr', 'Acabamento', 'Limpeza'] as const;

export const INITIAL_CHECKLIST: Omit<QualityReport, 'id' | 'projectId' | 'date' | 'score' | 'bonusAmount' | 'installerId'> = {
  inspectorName: '',
  items: [
    { id: '1', axis: 'Estrutura', label: 'Prumo e Nivelamento', passed: null },
    { id: '2', axis: 'Estrutura', label: 'Fixação de Painéis', passed: null },
    { id: '3', axis: 'Funcionamento', label: 'Regulagem de Dobradiças', passed: null },
    { id: '4', axis: 'Funcionamento', label: 'Amortecimento de Gavetas', passed: null },
    { id: '5', axis: 'Portas de Correr', label: 'Alinhamento de Trilhos', passed: null },
    { id: '6', axis: 'Acabamento', label: 'Colagem de Fitas de Borda', passed: null },
    { id: '7', axis: 'Acabamento', label: 'Siliconamento de Junções', passed: null },
    { id: '8', axis: 'Limpeza', label: 'Remoção de Resíduos de Cola', passed: null },
    { id: '9', axis: 'Limpeza', label: 'Poeira Interna e Externa', passed: null },
    { id: '10', axis: 'Limpeza', label: 'Brilho das Frentes', passed: null },
  ]
};
